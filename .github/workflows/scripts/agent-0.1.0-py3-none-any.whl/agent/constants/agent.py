"""
Constants related to configuration files and settings.
"""

import os


# Path to the main agent configuration directory
CONFIG_DIR = os.path.abspath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "agent_config")
)

# Path to the main agent configuration file
CONFIG_FILE = "config.yaml"

# Path to built-in tools
BUILTIN_TOOLS_PATH = os.path.abspath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tool")
)

# Path to custom tools
CUSTOM_TOOLS_PATH = "custom_module"

"""
Constants related to logging configuration.
"""

# Root logger name for the project
LOGGER_NAME = "Agent"

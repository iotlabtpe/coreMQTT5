"""
Constants related to conversation with LLM.
"""

# Role used to identify user messages in conversations with the LLM
AGENT_USER_CONVERSATION_ROLE = "user"

# Retry delay in seconds when retrying conversation
AGENT_CONVERSE_RETRY_SECONDS = 5.0

# Maximum number of retries for API calls
AGENT_CONVERSE_MAX_RETRIES = 5

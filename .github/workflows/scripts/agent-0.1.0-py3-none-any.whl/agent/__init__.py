"""
Command-line interface package for the agent.
"""

from .main import main_wrapper

__all__ = ["main_wrapper"]
from typing import List

import yaml

from .config import (
    AgentConfig,
    KnowledgeConfig,
    McpServerConfig,
    PlatformConfig,
    SystemPromptConfig,
)
from .exceptions import ConfigurationError


class ConfigLoader:
    def __init__(self, config_path: str):
        self.agent_config = None
        self.config_path = config_path
        self._load_config()

    def _load_config(self) -> AgentConfig:
        try:
            with open(self.config_path, "r") as file:
                config_data = yaml.safe_load(file)

            if not config_data:
                raise ConfigurationError(
                    "Empty or invalid YAML configuration file", self.config_path
                )

            # Build the agent configuration
            self.agent_config = AgentConfig.from_dict(config_data)
            return self.agent_config

        except ConfigurationError:
            # Re-raise ConfigurationError as is
            raise
        except Exception as e:
            # Wrap other exceptions
            raise ConfigurationError(f"Failed to load agent configuration: {str(e)}")

    def get_agent_config(self) -> AgentConfig:
        """Get the complete agent configuration.

        Returns:
            The complete agent configuration object
        """
        return self.agent_config

    def get_platform_config(self) -> PlatformConfig:
        """Get the platform configuration.

        Returns:
            The platform configuration
        """
        return self.agent_config.platform

    def get_system_prompt_config(self) -> SystemPromptConfig:
        """Get the system prompt configuration.

        Returns:
            The system prompt configuration
        """
        return self.agent_config.systemPrompt

    def get_mcp_servers_config(self) -> List[McpServerConfig]:
        """Get the list of MCP server configurations.

        Returns:
            List of MCP server configurations
        """
        return self.agent_config.mcpServers

    def get_knowledge_bases_config(self) -> List[KnowledgeConfig]:
        """Get the list of knowledge base configurations.

        Returns:
            List of knowledge base configurations
        """
        return self.agent_config.knowledgeBases

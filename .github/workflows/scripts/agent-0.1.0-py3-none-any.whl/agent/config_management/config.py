from dataclasses import dataclass, field
from typing import Dict, List, Optional, Type, TypeVar

from .exceptions import ConfigurationError

T = TypeVar("T", bound="BaseConfig")


class BaseConfig:
    """Base configuration class with common functionality."""

    # Override in subclasses to specify required fields
    _required_fields = []  # List of required field names

    def __post_init__(self):
        """Validate required fields."""
        # Get config name from class name (e.g., PlatformConfig -> platform)
        config_name = self.__class__.__name__.replace("Config", "").lower()

        for field_name in self._required_fields:
            if not getattr(self, field_name, None):
                error_context = f"{config_name}.{field_name}"
                raise ConfigurationError(
                    f"{field_name.capitalize()} is required", error_context
                )

    @classmethod
    def from_dict(cls: Type[T], data: Dict) -> T:
        """Create a configuration instance from a dictionary.

        Args:
            data: Dictionary containing configuration

        Returns:
            Configuration instance

        Raises:
            ConfigurationError: If required fields are missing
        """
        if not data:
            context = cls.__name__.lower()
            raise ConfigurationError(f"Missing {context} configuration", context)

        # Let the subclass handle instantiation
        return cls(**{k: data.get(k) for k in cls.__annotations__ if k in data})


@dataclass
class PlatformConfig(BaseConfig):
    """Configuration for the AI platform."""

    name: str
    provider: str
    model: str
    env: Dict[str, str] = field(default_factory=dict)

    _required_fields = ["name", "provider", "model"]


@dataclass
class SystemPromptConfig(BaseConfig):
    """Configuration for system prompt with mutually exclusive text or file source."""

    text: Optional[str] = None
    file: Optional[str] = None

    def __post_init__(self):
        """Validate the configuration."""
        # Call parent's validation first
        super().__post_init__()

        # Special validation for mutually exclusive fields
        config_name = self.__class__.__name__.replace("Config", "").lower()
        error_context = f"{config_name}"

        if self.text is not None and self.file is not None:
            raise ConfigurationError(
                "Only one of 'text' or 'file' can be provided, not both",
                error_context,
            )
        if self.text is None and self.file is None:
            raise ConfigurationError(
                "At least one of 'text' or 'file' must be provided",
                error_context,
            )


@dataclass
class McpServerConfig(BaseConfig):
    """Configuration for MCP server."""

    name: str
    command: str
    args: List[str]
    env: Dict[str, str] = field(default_factory=dict)

    _required_fields = ["name", "command", "args"]


@dataclass
class KnowledgeConfig(BaseConfig):
    """Configuration for knowledge base."""

    name: str
    description: str
    provider: str
    id: str
    env: Dict[str, str] = field(default_factory=dict)

    _required_fields = ["name", "description", "provider", "id"]


@dataclass
class AgentConfig(BaseConfig):
    """Main configuration for the agent combining all components."""

    platform: PlatformConfig
    systemPrompt: SystemPromptConfig
    mcpServers: List[McpServerConfig] = field(default_factory=list)
    knowledgeBases: List[KnowledgeConfig] = field(default_factory=list)

    _required_fields = ["platform", "systemPrompt"]

    @classmethod
    def from_dict(cls, data: Dict) -> "AgentConfig":
        """Create an AgentConfig from a dictionary with validation.

        Args:
            data: Dictionary containing agent configuration

        Returns:
            AgentConfig instance

        Raises:
            ConfigurationError: If required fields are missing
        """
        if not data:
            raise ConfigurationError("Empty configuration data", "AgentConfig")

        # Create platform config
        platform = PlatformConfig.from_dict(data.get("platform", {}))

        # Create system prompt config
        system_prompt = SystemPromptConfig.from_dict(data.get("systemPrompt", {}))

        # Create MCP server configs
        mcp_servers = []
        for server_data in data.get("mcpServers", []):
            mcp_servers.append(McpServerConfig.from_dict(server_data))

        # Create knowledge base configs
        knowledge_bases = []
        for kb_data in data.get("knowledgeBases", []):
            knowledge_bases.append(KnowledgeConfig.from_dict(kb_data))

        return cls(
            platform=platform,
            systemPrompt=system_prompt,
            mcpServers=mcp_servers,
            knowledgeBases=knowledge_bases,
        )

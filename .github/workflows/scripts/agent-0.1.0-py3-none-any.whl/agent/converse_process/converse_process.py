"""
Module for managing the conversation process and tool handling loop.
"""

import dataclasses
from typing import Any, Dict, List, Optional

from agent import tool_management
from agent.config_management import PlatformConfig
from agent.constants.converse import AGENT_USER_CONVERSATION_ROLE
from agent.utility import Log

from .factory import RequestProcessorFactory, ResponseHandlerFactory
from .message_management import MessageManager
from .stop_reason import StopReason

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class ConversationProcessor:
    """
    Class to manage the conversation process and tool handling loop.
    """

    def __init__(
        self,
        tool_config: Dict[str, Any],
        system_prompt: List[Dict[str, Any]],
        platform_config: PlatformConfig,
    ):
        """
        Initialize the ConversationProcessor.

        Args:
            tool_config: Tool information to send to the model.
            system_prompt: The system prompt to use.
            platform_config: The LLM provider configuration.
        """
        self.message_manager = MessageManager()

        # Use factories to create appropriate request processor and response handler
        self.request_handler = RequestProcessorFactory.create(
            tool_config=tool_config,
            system_prompt=system_prompt,
            platform_config=platform_config,
        )
        self.response_handler = ResponseHandlerFactory.create(platform_config)

    def _stream_messages(
        self,
        text: Optional[str] = None,
        tool_results: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[str]:
        """
        Sends a message to the model and streams the response.

        Args:
            text: The input text message.
            tool_results: List of tool results from previous tool executions.

        Returns:
            The reason why the model stopped generating text.
        """
        # Process request messages
        if text:
            self.message_manager.add_text_message(AGENT_USER_CONVERSATION_ROLE, text)

        if tool_results:
            self.message_manager.add_tool_result(tool_results)

        response = self.request_handler.send_request(
            messages=self.message_manager.get_messages()
        )

        # Handle response message
        stop_reason, rsp_message = self.response_handler.process_stream_response(
            response
        )
        self.message_manager.add_message(rsp_message["role"], rsp_message["content"])
        logger.debug("Response processed with stop reason: %s", stop_reason)

        return stop_reason

    async def process_message(self, input_text: str) -> Optional[str]:
        """
        Process the conversation including tool handling loop.

        Args:
            input_text: The initial input text from the user.

        Returns:
            The final stop reason after processing the conversation.
        """
        stop_reason = self._stream_messages(text=input_text)

        while stop_reason == StopReason.TOOL_USE:
            logger.info("Processing tool use request")
            tool_results = [
                dataclasses.asdict(
                    await tool_management.process_tool(content["toolUse"])
                )
                for content in self.message_manager.get_last_message()["content"]
                if "toolUse" in content
            ]

            logger.debug("Tool execution completed with %d results", len(tool_results))
            stop_reason = self._stream_messages(tool_results=tool_results)

        return stop_reason

    def clear_messages(self) -> None:
        """Clear all messages in the conversation."""
        self.message_manager.clear()

    def get_messages(self) -> List[Dict[str, Any]]:
        """
        Get all messages in the conversation.

        Returns:
            The list of all messages in the conversation.
        """
        return self.message_manager.get_messages()

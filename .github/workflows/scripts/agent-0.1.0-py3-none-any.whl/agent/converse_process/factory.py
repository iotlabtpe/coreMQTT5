"""
Module for factory classes to create request processors and response handlers.
"""

from typing import Any, Dict, List

from agent.config_management import PlatformConfig

from .bedrock import BedrockRequestProcessor, BedrockResponseHandler
from .request_process import BaseRequestProcessor
from .response_handle import BaseResponseHandler


class RequestProcessorFactory:
    """
    Factory class for creating request processor instances based on platform configuration.
    """

    @staticmethod
    def create(
        tool_config: Dict[str, Any],
        system_prompt: List[Dict[str, Any]],
        platform_config: PlatformConfig,
    ) -> BaseRequestProcessor:
        """
        Create a request processor instance based on the platform provider.

        Args:
            tool_config: Tool information to send to the model.
            system_prompt: The system prompt to use.
            platform_config: The LLM provider configuration.

        Returns:
            An instance of a request processor.

        Raises:
            ValueError: If the platform provider is not supported.
        """
        provider = platform_config.provider.lower()
        if provider == "bedrock":
            return BedrockRequestProcessor(tool_config, system_prompt, platform_config)

        raise ValueError(f"Unsupported platform provider: {platform_config.provider}")


class ResponseHandlerFactory:
    """
    Factory class for creating response handler instances based on platform configuration.
    """

    @staticmethod
    def create(platform_config: PlatformConfig) -> BaseResponseHandler:
        """
        Create a response handler instance based on the platform provider.

        Args:
            platform_config: The LLM provider configuration.

        Returns:
            An instance of a response handler.

        Raises:
            ValueError: If the platform provider is not supported.
        """
        provider = platform_config.provider.lower()
        if provider == "bedrock":
            return BedrockResponseHandler()

        raise ValueError(f"Unsupported platform provider: {platform_config.provider}")

"""
Module defining the base class for request processing.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List

from agent.config_management import PlatformConfig


class BaseRequestProcessor(ABC):
    """
    Abstract base class for request processing.

    This class defines the interface for all request processors
    that handle sending requests to different LLM providers.
    """

    def __init__(
        self,
        tool_config: Dict[str, Any],
        system_prompt: List[Dict[str, Any]],
        platform_config: PlatformConfig,
    ):
        """
        Initialize the BaseRequestProcessor.

        Args:
            tool_config: Tool information to send to the model.
            system_prompt: The system prompt to use.
            platform_config: The LLM provider configuration.
        """
        self.tool_config = tool_config
        self.system_prompt = system_prompt
        self.platform_config = platform_config

    @abstractmethod
    def send_request(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Send a request to the LLM provider.

        Args:
            messages: The messages to send to the model.

        Returns:
            The response from the LLM provider.
        """
        pass

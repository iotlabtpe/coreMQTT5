"""
Module for managing conversation messages.
"""

from typing import Any, Dict, List, Optional

from agent.constants.converse import AGENT_USER_CONVERSATION_ROLE
from agent.utility import Log

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class MessageManager:
    """
    Class to maintain and manage messages for a conversation.

    This class provides functionality to add, retrieve, and manipulate
    conversation messages between a user and an AI assistant.
    """

    def __init__(self):
        """Initialize an empty message list."""
        self.messages: List[Dict[str, Any]] = []

    def add_message(self, role: str, content: List[Dict[str, Any]]) -> None:
        """
        Add a new message to the conversation.

        Args:
            role: The role of the message sender (e.g., 'user', 'assistant').
            content: The content of the message.
        """
        self.messages.append({"role": role, "content": content})
        logger.debug("Added message with role: %s", role)

    def add_text_message(self, role: str, text: str) -> None:
        """
        Add a simple text message to the conversation.

        Args:
            role: The role of the message sender (e.g., 'user', 'assistant').
            text: The text content of the message.
        """
        self.add_message(role, [{"text": text}])

    def add_tool_result(self, tool_results: List[Dict[str, Any]]) -> None:
        """
        Add a tool result message to the conversation.

        Args:
            tool_results: List of tool results to add.
        """
        content = [{"toolResult": result} for result in tool_results]
        self.add_message(AGENT_USER_CONVERSATION_ROLE, content)

    def get_messages(self) -> List[Dict[str, Any]]:
        """
        Get all messages in the conversation.

        Returns:
            The list of messages.
        """
        return self.messages

    def clear(self) -> None:
        """Clear all messages in the conversation."""
        message_count = len(self.messages)
        self.messages = []
        logger.info("Cleared %d messages from conversation", message_count)

    def get_last_message(self) -> Optional[Dict[str, Any]]:
        """
        Get the last message in the conversation.

        Returns:
            The last message or None if there are no messages.
        """
        return self.messages[-1] if self.messages else None

"""
Enum definitions for conversation stop reasons.
"""

from enum import Enum, auto
from typing import Optional


class AutoNameEnum(str, Enum):
    """Base enum class that converts member names to lowercase values."""

    def _generate_next_value_(name, start, count, last_values):
        return name.lower()


class StopReason(AutoNameEnum):
    """
    Enum for conversation stop reasons.
    """

    TOOL_USE = auto()
    END_TURN = auto()
    MAX_TOKENS = auto()
    TERMINATE_TURN = auto()
    ERROR = auto()

    @classmethod
    def from_value(cls, value: str) -> Optional["StopReason"]:
        """
        Get enum member from value using reflection.

        Args:
            value: The string value to look up

        Returns:
            The matching enum member or None if not found
        """
        try:
            return cls(value)
        except ValueError:
            return None

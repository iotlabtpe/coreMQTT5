"""
Module for handling responses from Amazon Bedrock.
"""

import json
from typing import Any, Dict, Optional, Tuple

from agent.utility import Log

from ..response_handle import BaseResponseHandler
from ..stop_reason import StopReason

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class BedrockResponseHandler(BaseResponseHandler):
    """
    Class to handle responses from Amazon Bedrock.
    """

    def process_stream_response(
        self, response: Dict[str, Any]
    ) -> Tuple[Optional[StopReason], Dict[str, Any]]:
        """
        Process a streaming response from Amazon Bedrock.

        Args:
            response: The streaming response from Amazon Bedrock.

        Returns:
            Tuple containing:
                - The reason why the model stopped generating text.
                - The processed message.
        """
        message = {"content": []}
        current_content = {"tool_use": {}, "text": ""}
        stop_reason_value = None

        for chunk in response["stream"]:
            if "messageStart" in chunk:
                message["role"] = chunk["messageStart"]["role"]
            elif "contentBlockStart" in chunk:
                start = chunk["contentBlockStart"]["start"]
                if "toolUse" in start:
                    current_content["tool_use"]["toolUseId"] = start["toolUse"][
                        "toolUseId"
                    ]
                    current_content["tool_use"]["name"] = start["toolUse"]["name"]
            elif "contentBlockDelta" in chunk:
                delta = chunk["contentBlockDelta"]["delta"]
                if "toolUse" in delta:
                    current_content["tool_use"].setdefault("input", "")
                    current_content["tool_use"]["input"] += delta["toolUse"].get(
                        "input", ""
                    )
                elif "text" in delta:
                    current_content["text"] += delta["text"]
                    log.console.print(delta["text"], end="")
            elif "contentBlockStop" in chunk:
                if current_content["tool_use"]:
                    tool_use = current_content["tool_use"]
                    tool_use["input"] = json.loads(
                        tool_use["input"] if tool_use.get("input") else "{}"
                    )
                    message["content"].append({"toolUse": tool_use})
                elif current_content["text"] and not all(
                    char.isspace() for char in current_content["text"]
                ):
                    message["content"].append({"text": current_content["text"]})
                current_content = {"tool_use": {}, "text": ""}
            elif "messageStop" in chunk:
                stop_reason_value = chunk["messageStop"]["stopReason"]
                logger.debug("Response stopped with reason: %s", stop_reason_value)
                log.console.print("\n", end="")

        # Map Bedrock stop reasons to our StopReason enum
        stop_reason_mapping = {
            "tool_use": StopReason.TOOL_USE,
            "end_turn": StopReason.END_TURN,
            "max_tokens": StopReason.MAX_TOKENS,
            "stop_sequence": StopReason.TERMINATE_TURN,
            "guardrail_intervened": StopReason.TERMINATE_TURN,
            "content_filtered": StopReason.TERMINATE_TURN,
        }

        return stop_reason_mapping.get(stop_reason_value, StopReason.ERROR), message

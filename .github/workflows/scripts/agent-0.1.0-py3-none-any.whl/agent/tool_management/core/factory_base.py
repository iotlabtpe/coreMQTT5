"""
Module for creating dynamic tool handler classes.
"""

import inspect
from functools import wraps
from typing import Any, Callable, Dict, Type

from agent.utility import Log
from ..model import (
    InputSchema,
    ToolConfig,
    ToolHandler,
    ToolResult,
    ToolSpec,
)

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class ToolFactory:
    """
    Factory for creating dynamic tool handler classes.
    """

    @classmethod
    def create_handler_class(
        cls,
        name: str,
        description: str,
        input_schema: InputSchema,
        execute_method: Callable,
    ) -> Type[ToolHandler]:
        """
        Create a dynamic ToolHandler subclass.

        Args:
            name: Tool name
            description: Tool description
            input_schema: Schema for tool inputs
            execute_method: Method to handle execution

        Returns:
            A dynamically created ToolHandler subclass

        Raises:
            ValueError: If execute_method doesn't meet requirements
        """
        cls._validate_execute_method(execute_method)

        # Create schema class method
        def schema_method(cls) -> ToolConfig:
            return ToolConfig(
                toolSpec=ToolSpec(
                    name=name, description=description, inputSchema=input_schema
                )
            )

        # Create execute class method
        @wraps(execute_method)
        async def exec_method(cls, tool: Dict[str, Any]) -> ToolResult:
            return await execute_method(cls, tool)

        # Create dynamic class
        class_name = f"Dynamic{name.title()}Handler"
        logger.debug("Creating dynamic tool handler class: %s", class_name)
        return type(
            class_name,
            (ToolHandler,),
            {"schema": classmethod(schema_method), "execute": classmethod(exec_method)},
        )

    @staticmethod
    def _validate_execute_method(method: Callable) -> None:
        """
        Validate the execute method signature.

        Args:
            method: Method to validate

        Raises:
            ValueError: If method doesn't meet requirements
        """
        if not inspect.iscoroutinefunction(method):
            logger.error("Execute method validation failed: not an async function")
            raise ValueError("Execute method must be an async function")

        sig = inspect.signature(method)
        params = list(sig.parameters.values())

        if len(params) < 2:  # cls, tool
            logger.error("Execute method validation failed: insufficient parameters")
            raise ValueError(
                "Execute method must accept at least two parameters (cls, tool)"
            )

        # Check return annotation if available
        return_annotation = sig.return_annotation
        if (
            return_annotation != ToolResult
            and return_annotation != inspect.Signature.empty
        ):
            logger.error("Execute method validation failed: incorrect return type")
            raise ValueError("Execute method must return ToolResult")

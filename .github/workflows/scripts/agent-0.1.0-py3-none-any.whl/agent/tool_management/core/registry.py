"""
Module for tool handler registration and management.
"""

from collections import defaultdict
from typing import Dict, Type

from agent.utility import Log

from ..model import ToolHandler

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class ToolRegistry:
    """
    Registry for tool handlers using the Singleton pattern.

    This class maintains a global registry of tool handlers that can be
    accessed from anywhere in the application.
    """

    _instance = None
    _handlers: Dict[str, Type[ToolHandler]] = defaultdict(dict)

    def __new__(cls):
        """Ensure only one instance exists (Singleton pattern)."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def register(cls, name: str, handler_class: Type[ToolHandler]) -> None:
        """
        Register a tool handler class.

        Args:
            name: Tool name
            handler_class: Handler class to register

        Raises:
            ValueError: If handler_class is not a ToolHandler subclass
        """
        if not issubclass(handler_class, ToolHandler):
            raise ValueError("Handler class must inherit from ToolHandler")
        cls._handlers[name] = handler_class
        logger.debug("Registered tool handler: %s", name)

    @classmethod
    def create(cls, name: str) -> ToolHandler:
        """
        Create a tool handler instance.

        Args:
            name: Tool name

        Returns:
            An instance of the requested tool handler

        Raises:
            ValueError: If tool name is not registered
        """
        if name not in cls._handlers:
            logger.error("Attempted to create unknown tool handler: %s", name)
            raise ValueError(f"Unknown tool handler: {name}")
        logger.debug("Creating tool handler instance: %s", name)
        return cls._handlers[name]()

    @classmethod
    def get_all(cls) -> Dict[str, Type[ToolHandler]]:
        """
        Get all registered handlers.

        Returns:
            Dictionary of registered tool handlers
        """
        return cls._handlers.copy()

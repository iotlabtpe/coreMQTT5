"""
Type definitions for tool management.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ToolResult:
    """
    Result of a tool execution.

    Contains the tool use ID, content to return to the model,
    and status of the execution.
    """

    toolUseId: str
    content: List[Dict[str, Any]] = field(default_factory=list)
    status: str = field(default="success")


@dataclass
class InputSchemaProperty:
    """
    Property definition for tool input schema.

    Defines the type, description, and constraints for a single
    property in a tool's input schema.
    """

    type: str = field(default="string")
    description: str = field(default="No description for this property")
    enum: Optional[List[Any]] = field(default=None)
    items: Optional["InputSchemaProperty"] = field(default=None)


@dataclass
class InputSchemaJson:
    """
    JSON schema definition for tool input.

    Defines the structure of a tool's input using JSON Schema format.
    """

    type: str = field(default="object")
    properties: Dict[str, InputSchemaProperty] = field(default_factory=dict)
    required: List[str] = field(default_factory=list)


@dataclass
class InputSchema:
    """
    Input schema for a tool.

    Wraps the JSON schema definition for a tool's input.
    """

    json: InputSchemaJson = field(default_factory=InputSchemaJson)


@dataclass
class ToolSpec:
    """
    Specification for a tool.

    Defines the name, description, and input schema for a tool.
    """

    name: str
    description: str
    inputSchema: InputSchema = field(default_factory=InputSchema)


@dataclass
class ToolConfig:
    """
    Configuration for a tool.

    Contains the tool specification.
    """

    toolSpec: ToolSpec


class ToolHandler(ABC):
    """
    Base abstract class for all tool handlers.

    Tool handlers are responsible for executing tools and providing their schemas.
    All concrete tool implementations must inherit from this class and implement
    the required abstract methods.
    """

    @classmethod
    @abstractmethod
    def schema(cls) -> ToolConfig:
        """
        Return the tool configuration schema.

        Returns:
            The tool configuration.
        """
        pass

    @classmethod
    @abstractmethod
    async def execute(cls, tool: Dict[str, Any]) -> ToolResult:
        """
        Execute the tool with the given input.

        Args:
            tool: The tool request with input parameters.

        Returns:
            The result of the tool execution.
        """
        pass

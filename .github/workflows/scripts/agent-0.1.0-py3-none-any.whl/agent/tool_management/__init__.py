"""
Package for tool management and execution.

This package provides functionality for:
1. Registering and managing tool handlers
2. Loading tool handlers from modules
3. Creating dynamic tool handlers
4. Executing tools and processing results
5. Integration with MCP (Machine Comprehension Protocol)
"""

import dataclasses
from typing import Any, Dict

from .core import ToolRegistry
from .model import ToolResult
from agent.utility import Log

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


async def process_tool(tool: Dict[str, Any]) -> ToolResult:
    """
    Process a tool request by finding and executing the appropriate handler.

    Args:
        tool: Tool request dictionary containing name, toolUseId, and input

    Returns:
        Tool execution result
    """
    try:
        handler = ToolRegistry().create(tool["name"])
        return await handler.execute(tool)
    except Exception as err:
        logger.error("Tool execution error: %s", str(err))
        return ToolResult(
            toolUseId=tool["toolUseId"], content=[{"text": str(err)}], status="error"
        )


def _remove_none_factory(data):
    """
    Remove None values from dictionaries and lists.

    Used as a dict_factory for dataclasses.asdict() to clean up serialized output.

    Args:
        data: The data items to clean

    Returns:
        Cleaned data with None values removed
    """

    def clean_dict(d):
        if isinstance(d, dict):
            return {k: clean_dict(v) for k, v in d.items() if v is not None}
        if isinstance(d, list):
            return [clean_dict(item) for item in d]
        return d

    return {key: clean_dict(value) for key, value in data if value is not None}


def get_tool_schema(tool_name: str) -> Dict[str, Any]:
    """
    Get the schema for a tool.

    Args:
        tool_name: Name of the tool

    Returns:
        Tool schema as a dictionary with None values removed
    """
    handler = ToolRegistry().create(tool_name)
    return dataclasses.asdict(handler.schema(), dict_factory=_remove_none_factory)

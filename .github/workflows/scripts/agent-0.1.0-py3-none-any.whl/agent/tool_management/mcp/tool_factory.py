"""
Module for creating MCP tool handlers.
"""

from typing import Any, Dict, Type

from mcp import StdioServerParameters

from agent.config_management.config import McpServerConfig
from agent.constants.mcp import MCP_STDIO_PREFIX

from ..core import ToolFactory
from ..model import (
    InputSchema,
    ToolHandler,
    ToolResult,
)
from .client import McpClient


class McpToolFactory:
    """
    Factory for creating MCP tool handlers.

    This class extends the base ToolFactory to create handlers specifically
    for MCP tools.
    """

    @classmethod
    def create_handler_class(
        cls,
        name: str,
        description: str,
        input_schema: InputSchema,
        server_config: McpServerConfig,
    ) -> Type[ToolHandler]:
        """
        Create a tool handler class for MCP tools.

        Args:
            name: The name of the tool
            description: A description of the tool's functionality
            input_schema: The schema defining the tool's input parameters
            server_config: Configuration for the MCP server

        Returns:
            A dynamically created subclass of ToolHandler

        Raises:
            ValueError: If the tool name format is invalid
        """

        async def mcp_execute(_, tool: Dict[str, Any]) -> ToolResult:
            """
            Execute the MCP tool by calling the remote server.

            Args:
                tool: The tool request with input parameters

            Returns:
                The result of the tool execution

            Raises:
                ValueError: If the tool name format is invalid
            """
            if not tool["name"].startswith(MCP_STDIO_PREFIX):
                raise ValueError("Invalid MCP tool name prefix")

            # Extract function name from the tool name
            extracted_name = tool["name"][len(MCP_STDIO_PREFIX) :]
            parts = extracted_name.split("_", 1)

            if len(parts) != 2:
                raise ValueError("Invalid tool name format")

            _, function_name = parts

            # Create server parameters and call the tool
            stdio_params = StdioServerParameters(
                command=server_config.command,
                args=server_config.args,
                env=server_config.env,
            )

            async with McpClient(stdio_params) as client:
                result = await client.call_tool(function_name, arguments=tool["input"])
                return ToolResult(
                    toolUseId=tool["toolUseId"],
                    content=[{"text": str(result)}],
                )

        # Use the base factory to create the handler class
        return ToolFactory.create_handler_class(
            name=name,
            description=description,
            input_schema=input_schema,
            execute_method=mcp_execute,
        )

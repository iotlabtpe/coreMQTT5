"""
Module for managing MCP servers and tool registration.
"""

import asyncio
import logging
from typing import Dict, List

from mcp import StdioServerParameters

from agent.config_management.config import McpServerConfig
from agent.constants.mcp import MCP_STDIO_PREFIX

from ..core import ToolRegistry
from .client import McpClient
from .tool_factory import McpToolFactory

logger = logging.getLogger(__name__)


class McpServerManager:
    """
    Manager for MCP servers and tool registration.

    This class handles the discovery and registration of tools from MCP servers.
    """

    def __init__(self):
        """Initialize the server manager."""
        self.servers: Dict[str, asyncio.subprocess.Process] = {}
        self.clients: Dict[str, McpClient] = {}

    async def register_available_tools(
        self, server_configs: List[McpServerConfig]
    ) -> None:
        """
        Register all available tools from configured MCP servers.

        Args:
            server_configs: List of MCP server configurations

        Raises:
            Exception: If tool registration fails
        """
        for server_config in server_configs:
            await self._register_server_tools(server_config)

    async def _register_server_tools(self, server_config: McpServerConfig) -> None:
        """
        Register tools from a single MCP server.

        Args:
            server_config: Configuration for the MCP server

        Raises:
            Exception: If tool registration fails
        """
        stdio_params = StdioServerParameters(
            command=server_config.command,
            args=server_config.args,
            env=server_config.env,
        )

        async with McpClient(stdio_params) as client:
            tools = await client.get_available_tools()

            for tool in tools:
                tool_name = f"{MCP_STDIO_PREFIX}{server_config.name}_{tool.name}"

                try:
                    handler_class = McpToolFactory.create_handler_class(
                        name=tool_name,
                        description=tool.description,
                        input_schema={"json": tool.inputSchema},
                        server_config=server_config,
                    )

                    ToolRegistry().register(tool_name, handler_class)
                    logger.debug("Registered MCP tool: %s", tool_name)

                except Exception as e:
                    logger.error("Failed to register handler %s: %s", tool.name, str(e))
                    raise

"""
Module containing built-in test tools.
"""

from typing import Any, Dict

from ..tool_management.model import (
    InputSchema,
    InputSchemaJson,
    InputSchemaProperty,
    ToolConfig,
    ToolHandler,
    ToolResult,
    ToolSpec,
)


class TestStaticHandler(ToolHandler):
    """
    A simple test tool handler that echoes the input message.

    This handler is used for testing the tool execution framework.
    """

    @classmethod
    def schema(cls) -> ToolConfig:
        """
        Define the tool schema.

        Returns:
            The tool configuration.
        """
        return ToolConfig(
            toolSpec=ToolSpec(
                name="static_test_tool3",
                description="Echo the input for testing tool use",
                inputSchema=InputSchema(
                    json=InputSchemaJson(
                        properties={
                            "message": InputSchemaProperty(
                                type="string",
                                description="The message to echo",
                            ),
                        },
                        required=["message"],
                    )
                ),
            )
        )

    @classmethod
    async def execute(cls, tool: Dict[str, Any]) -> ToolResult:
        """
        Execute the tool by echoing back the input message.

        Args:
            tool: The tool request with input parameters.

        Returns:
            The result containing the echoed message.
        """
        return ToolResult(
            toolUseId=tool["toolUseId"], content=[{"text": tool["input"]["message"]}]
        )

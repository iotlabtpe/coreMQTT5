from typing import Any, Dict

from agent.tool_management.model import (
    InputSchema,
    InputSchemaJson,
    InputSchemaProperty,
    ToolConfig,
    ToolHandler,
    ToolResult,
    ToolSpec,
)


class TestStaticHandler1(ToolHandler):
    @classmethod
    def schema(cls) -> ToolConfig:
        return ToolConfig(
            toolSpec=ToolSpec(
                name="static_test_tool1",
                description="Echo the input for testing tool use",
                inputSchema=InputSchema(
                    json=InputSchemaJson(
                        properties={
                            "message": InputSchemaProperty(
                                type="string",
                                description="The message to echo",
                            ),
                        },
                        required=["message"],
                    )
                ),
            )
        )

    @classmethod
    async def execute(self, tool: Dict[str, Any]) -> ToolResult:
        return ToolResult(
            toolUseId=tool["toolUseId"], content=[{"text": tool["input"]["message"]}]
        )


class TestStaticHandler2(ToolHandler):
    @classmethod
    def schema(cls) -> ToolConfig:
        return ToolConfig(
            toolSpec=ToolSpec(
                name="static_test_tool2",
                description="Echo the input for testing tool use",
                inputSchema=InputSchema(
                    json=InputSchemaJson(
                        properties={
                            "message": InputSchemaProperty(
                                type="string",
                                description="The message to echo",
                            ),
                        },
                        required=["message"],
                    )
                ),
            )
        )

    @classmethod
    async def execute(self, tool: Dict[str, Any]) -> ToolResult:
        return ToolResult(
            toolUseId=tool["toolUseId"], content=[{"text": tool["input"]["message"]}]
        )

"""
Command-line interface for the conversation agent.
"""

import os
from typing import Dict, List, Optional

from botocore.exceptions import ClientError

from agent import tool_management
from agent.config_management.config_loader import ConfigLoader
from agent.config_management.knowledge_base_config_lookup import (
    KnowledgeBaseConfigLookup,
)
from agent.constants.agent import (
    BUILTIN_TOOLS_PATH,
    CONFIG_DIR,
    CONFIG_FILE,
    CUSTOM_TOOLS_PATH,
)
from agent.constants.prompt import KNOWLEDGE_BASE_USAGE_PROMPT
from agent.converse_process import ConversationProcessor, StopReason
from agent.tool_management.core import ToolLoader, ToolRegistry
from agent.tool_management.mcp import McpServerManager
from agent.utility import Log

# Get logger instance
log = Log()
logger = log.get_logger(__name__)


class AgentCLI:
    """
    Command-line interface for the conversation agent.

    This class handles the setup and execution of the conversation agent
    from the command line, including tool registration and user interaction.
    """

    def __init__(self, config_dir: str = CONFIG_DIR):
        """
        Initialize the agent CLI.

        Args:
            config_dir: Path to the configuration directory
        """
        self.config_dir = config_dir
        self.config_loader = ConfigLoader(os.path.join(self.config_dir, CONFIG_FILE))
        self.converse_processor = None

    async def setup(self) -> None:
        """
        Set up the agent by loading configuration and registering tools.
        """
        # Load knowledge base configurations
        kb_list = []

        for kb in self.config_loader.get_knowledge_bases_config():
            KnowledgeBaseConfigLookup().add(
                provider=kb.provider,
                knowledge_base_id=kb.id,
                config=kb.env,
            )
            kb_list.append(
                f"- Provider = {kb.provider}, ID = {kb.id}, description = {kb.description}"
            )

        # Format the knowledge base prompt with the appropriate list or message
        if kb_list:
            kb_list_text = "\n".join(kb_list)
            knowledge_base_usage_prompt = KNOWLEDGE_BASE_USAGE_PROMPT.format(
                kb_list_placeholder=f"Below are the ONLY knowledge bases you can query:\n{kb_list_text}"
            )
        else:
            knowledge_base_usage_prompt = KNOWLEDGE_BASE_USAGE_PROMPT.format(
                kb_list_placeholder="No knowledge bases are currently available. DO NOT attempt to use knowledge base tools."
            )

        # Load system prompt
        system_prompt = self._load_system_prompt()
        system_prompt[0]["text"] += knowledge_base_usage_prompt

        # Register tools
        tool_config = await self._register_tools()

        # Create conversation processor
        self.converse_processor = ConversationProcessor(
            tool_config=tool_config,
            system_prompt=system_prompt,
            platform_config=self.config_loader.get_platform_config(),
        )

    def _load_system_prompt(self) -> List[Dict[str, str]]:
        """
        Load the system prompt from configuration.

        Returns:
            System prompt as a list of message objects
        """
        system_prompt_config = self.config_loader.get_system_prompt_config()

        if system_prompt_config.text:
            return [{"text": system_prompt_config.text}]
        elif system_prompt_config.file and os.path.exists(system_prompt_config.file):
            with open(system_prompt_config.file, "r") as f:
                return [{"text": f.read()}]

        logger.warning("No system prompt found in configuration")
        return []

    async def _register_tools(self) -> Dict:
        """
        Register all available tools.

        Returns:
            Tool configuration dictionary
        """
        # Register built-in tools
        for cls in ToolLoader.load_from_path(BUILTIN_TOOLS_PATH, "agent.tool"):
            ToolRegistry().register(cls().schema().toolSpec.name, cls)

        # Register custom tools
        for cls in ToolLoader.load_from_path(
            os.path.join(self.config_dir, CUSTOM_TOOLS_PATH)
        ):
            ToolRegistry().register(cls().schema().toolSpec.name, cls)

        # Register dynamic tools
        server_manager = McpServerManager()
        await server_manager.register_available_tools(
            self.config_loader.get_mcp_servers_config()
        )

        # Create tool config from schema
        return {
            "tools": [
                tool_management.get_tool_schema(tool_name)
                for tool_name in ToolRegistry().get_all().keys()
            ]
        }

    async def run_query(self, input_text) -> Optional[StopReason]:
        """
        Run the converse chat.
        """
        if not self.converse_processor:
            await self.setup()

        try:
            return await self.converse_processor.process_message(input_text)
        except ClientError as err:
            self._handle_client_error(err)
            return StopReason.ERROR

    async def run(self) -> None:
        """
        Run the interactive CLI loop.
        """

        while True:
            log.console.print(
                "Enter your question, request, or response for assistance.\n"
                "Available commands:\n"
                "- Type '/clear' to start a new conversation\n"
                "- Type '/quit' to exit the program",
                style="bold yellow",
            )

            input_text = self._get_user_input()

            if input_text == "/quit":
                log.console.print("Exiting program...", style="bold white")
                break

            if input_text == "/clear":
                log.console.print("Clearing the conversation...", style="bold white")
                self.converse_processor.clear_messages()
                continue

            stop_reason = await self.run_query(input_text)

            if self._should_terminate(stop_reason):
                log.console.print(
                    f"Stopping agent due to reason: {stop_reason.name}.",
                    style="bold red",
                )
                logger.warning("Agent stopped with reason: %s", stop_reason.name)
                break

    def _get_user_input(self) -> str:
        """
        Get and validate user input.

        Returns:
            Validated user input
        """
        input_text = input("> ").strip().lower()
        while not input_text:
            input_text = input("> ").strip().lower()
        return input_text

    def _should_terminate(self, stop_reason: Optional[StopReason]) -> bool:
        """
        Check if the conversation should be terminated.

        Args:
            stop_reason: The reason why the model stopped generating text

        Returns:
            True if the conversation should be terminated, False otherwise
        """
        return stop_reason in [
            StopReason.MAX_TOKENS,
            StopReason.TERMINATE_TURN,
            StopReason.ERROR,
        ]

    def _handle_client_error(self, err: ClientError) -> None:
        """
        Handle client errors by logging debug information.

        Args:
            err: The client error that occurred
        """
        if self.converse_processor:
            for index, msg in enumerate(self.converse_processor.get_messages(), 0):
                logger.debug("Debug messages[%d]: %s", index, msg)
        err_msg = err.response["Error"]["Message"]
        logger.error("A client error occurred: %s", err_msg)
